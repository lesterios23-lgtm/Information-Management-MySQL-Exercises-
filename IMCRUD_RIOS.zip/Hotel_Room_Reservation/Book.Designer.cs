﻿namespace Hotel_Room_Reservation
{
    partial class Book
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnback = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpout = new System.Windows.Forms.DateTimePicker();
            this.tbpay = new System.Windows.Forms.TextBox();
            this.cbroom = new System.Windows.Forms.ComboBox();
            this.tbcontact = new System.Windows.Forms.TextBox();
            this.tbemail = new System.Windows.Forms.TextBox();
            this.dtpin = new System.Windows.Forms.DateTimePicker();
            this.tbname = new System.Windows.Forms.TextBox();
            this.ndguest = new System.Windows.Forms.NumericUpDown();
            this.NAME = new System.Windows.Forms.Label();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ndguest)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.btnback);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dtpout);
            this.panel1.Controls.Add(this.tbpay);
            this.panel1.Controls.Add(this.cbroom);
            this.panel1.Controls.Add(this.tbcontact);
            this.panel1.Controls.Add(this.tbemail);
            this.panel1.Controls.Add(this.dtpin);
            this.panel1.Controls.Add(this.tbname);
            this.panel1.Controls.Add(this.ndguest);
            this.panel1.Controls.Add(this.NAME);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(423, 596);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnback.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnback.Location = new System.Drawing.Point(3, 3);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(121, 33);
            this.btnback.TabIndex = 37;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(223, 406);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 28);
            this.label7.TabIndex = 36;
            this.label7.Text = "Check out";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(77, 406);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 28);
            this.label6.TabIndex = 35;
            this.label6.Text = "Check In";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(223, 338);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 28);
            this.label5.TabIndex = 34;
            this.label5.Text = "Room Type";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(76, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 28);
            this.label4.TabIndex = 33;
            this.label4.Text = "No of Guest";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(76, 265);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 28);
            this.label3.TabIndex = 32;
            this.label3.Text = "Payment";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(77, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 28);
            this.label2.TabIndex = 31;
            this.label2.Text = "Contact No.";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(77, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 28);
            this.label1.TabIndex = 30;
            this.label1.Text = "E-mail ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dtpout
            // 
            this.dtpout.Location = new System.Drawing.Point(228, 437);
            this.dtpout.Name = "dtpout";
            this.dtpout.Size = new System.Drawing.Size(120, 22);
            this.dtpout.TabIndex = 29;
            this.dtpout.ValueChanged += new System.EventHandler(this.dtpout_ValueChanged);
            // 
            // tbpay
            // 
            this.tbpay.Location = new System.Drawing.Point(75, 297);
            this.tbpay.Multiline = true;
            this.tbpay.Name = "tbpay";
            this.tbpay.Size = new System.Drawing.Size(273, 38);
            this.tbpay.TabIndex = 28;
            this.tbpay.TextChanged += new System.EventHandler(this.tbpay_TextChanged);
            // 
            // cbroom
            // 
            this.cbroom.FormattingEnabled = true;
            this.cbroom.Items.AddRange(new object[] {
            "Single Bed ",
            "Double Bed",
            "family size "});
            this.cbroom.Location = new System.Drawing.Point(227, 369);
            this.cbroom.Name = "cbroom";
            this.cbroom.Size = new System.Drawing.Size(121, 24);
            this.cbroom.TabIndex = 27;
            this.cbroom.SelectedIndexChanged += new System.EventHandler(this.cbroom_SelectedIndexChanged);
            // 
            // tbcontact
            // 
            this.tbcontact.Location = new System.Drawing.Point(75, 224);
            this.tbcontact.Multiline = true;
            this.tbcontact.Name = "tbcontact";
            this.tbcontact.Size = new System.Drawing.Size(273, 38);
            this.tbcontact.TabIndex = 26;
            this.tbcontact.TextChanged += new System.EventHandler(this.tbcontact_TextChanged);
            // 
            // tbemail
            // 
            this.tbemail.Location = new System.Drawing.Point(75, 150);
            this.tbemail.Multiline = true;
            this.tbemail.Name = "tbemail";
            this.tbemail.Size = new System.Drawing.Size(273, 38);
            this.tbemail.TabIndex = 25;
            this.tbemail.TextChanged += new System.EventHandler(this.tbemail_TextChanged);
            // 
            // dtpin
            // 
            this.dtpin.Location = new System.Drawing.Point(75, 437);
            this.dtpin.Name = "dtpin";
            this.dtpin.Size = new System.Drawing.Size(120, 22);
            this.dtpin.TabIndex = 24;
            this.dtpin.ValueChanged += new System.EventHandler(this.dtpin_ValueChanged);
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(75, 83);
            this.tbname.Multiline = true;
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(273, 38);
            this.tbname.TabIndex = 23;
            this.tbname.TextChanged += new System.EventHandler(this.tbname_TextChanged);
            // 
            // ndguest
            // 
            this.ndguest.Location = new System.Drawing.Point(75, 369);
            this.ndguest.Name = "ndguest";
            this.ndguest.Size = new System.Drawing.Size(120, 22);
            this.ndguest.TabIndex = 22;
            this.ndguest.ValueChanged += new System.EventHandler(this.ndguest_ValueChanged);
            // 
            // NAME
            // 
            this.NAME.AutoSize = true;
            this.NAME.BackColor = System.Drawing.Color.Transparent;
            this.NAME.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NAME.Location = new System.Drawing.Point(77, 59);
            this.NAME.Name = "NAME";
            this.NAME.Size = new System.Drawing.Size(61, 28);
            this.NAME.TabIndex = 21;
            this.NAME.Text = "Name";
            this.NAME.Click += new System.EventHandler(this.NAME_Click);
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnsubmit.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsubmit.Location = new System.Drawing.Point(97, 496);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(222, 41);
            this.btnsubmit.TabIndex = 20;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = false;
            // 
            // Book
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 620);
            this.Controls.Add(this.panel1);
            this.Name = "Book";
            this.Text = "Book";
            this.Load += new System.EventHandler(this.Book_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ndguest)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpout;
        private System.Windows.Forms.TextBox tbpay;
        private System.Windows.Forms.ComboBox cbroom;
        private System.Windows.Forms.TextBox tbcontact;
        private System.Windows.Forms.TextBox tbemail;
        private System.Windows.Forms.DateTimePicker dtpin;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.NumericUpDown ndguest;
        private System.Windows.Forms.Label NAME;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnback;
    }
}