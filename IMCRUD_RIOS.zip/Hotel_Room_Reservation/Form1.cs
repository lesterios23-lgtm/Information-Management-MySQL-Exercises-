﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Hotel_Room_Reservation
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
            LoadRecord();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadRecord();
        }
        private void LoadRecord()
        {
            dgvcostumerlist.DataSource = dbconnect.GetAllReservation();
            dgvcostumerlist.Columns["id"].Visible = true;  
        }
        private void dgvcostumerlist_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void btnbook_Click(object sender, EventArgs e)
        {
            this.Hide();
            Book Book = new Book();
            Book.FormClosed += (s, args) => this.Close();
            Book.Show();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (dgvcostumerlist.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select row first");
                return;
            }
            int id = Convert.ToInt32(dgvcostumerlist.SelectedRows[0].Cells["id"].Value);

            this.Hide();
            update update = new update(0);
            update.FormClosed += (s, args) => this.Close();
            update.Show();
        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            if (dgvcostumerlist.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select row first");
                return;
            }
            int id = Convert.ToInt32(dgvcostumerlist.SelectedRows[0].Cells["id"].Value);
            dbconnect.Delete(id);
            LoadRecord();
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            string check = tbsearch.Text.Trim();
            if (string.IsNullOrEmpty(check))
            {
                MessageBox.Show("Enter your reservation name.");
                return;
            }
            foreach (DataGridViewRow row in dgvcostumerlist.Rows)
            {
                bool match = row.Cells["Name"].Value.ToString()
                    .IndexOf(check,StringComparison.OrdinalIgnoreCase) >= 0;
                row.Selected = match;   
                if (match)
                {
                    dgvcostumerlist.FirstDisplayedScrollingRowIndex = row.Index;
                    break;
                }

            }
        }
    }

    
    
}
