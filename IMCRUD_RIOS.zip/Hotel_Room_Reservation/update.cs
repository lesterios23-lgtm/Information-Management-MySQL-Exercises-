﻿using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hotel_Room_Reservation
{
    public partial class update :Form
    {
        public event EventHandler Reservationupdated;
        private int reservationid;
       
      
        public update(int id)
        {
            InitializeComponent();
            reservationid = id;
        }

        private void btnupdate_Click(object sender, EventArgs e, EventHandler update)
        {

            try
            {
                decimal pay = decimal.Parse(updatepay.Text);
                dbconnect.Insert(updatename.Text, updateemail.Text, (string)updatecontact.Text, updateroom.Text, (int)updateguest.Value, updatein.Value, updateout.Value, pay);

                MessageBox.Show("Update Successful!");
                Reservationupdated?.Invoke(this, EventArgs.Empty);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);

            }


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private int GetReservationid()
        {
            return reservationid;
        }

        private void Update_Load(object sender, EventArgs e)
        {
            DataTable Table = dbconnect.GetAllReservation();
            var rows = Table.Select($"id = {reservationid}");
            if (rows.Length > 0)
            {
                var row = rows[0];
                updatename.Text = row["Name"].ToString();
                updateemail.Text = row["Email"].ToString();
                updatecontact.Text = row["Contact_Number"].ToString();
                updateroom.Text = row["Room_Type"].ToString();
                updateguest.Text = row["Number_of_Guests"].ToString();
                updatein.Text = Convert.ToDateTime(row["Check_In"]).ToString("yyyy-MM-dd");
                updateout.Text = Convert.ToDateTime(row["Check_out"]).ToString("yyyy-MM-dd");
                updatepay.Text = row["Payment"].ToString();
            }
        }

       

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.FormClosed += (s, args) => this.Close();
            form1.Show();
        }
    }
}
