﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using Org.BouncyCastle.Bcpg;
using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


public static class dbconnect
{

    private static string conn = "server=localhost;userid=root;password=password;database = reservation";

    public static MySqlConnection getconn()
    {
        return new MySqlConnection(conn);
    }

    public static DataTable GetAllReservation()
    {
        DataTable tab = new DataTable();
        using (var conn = getconn())
        using (var cmd = new MySqlCommand("SELECT * FROM client", conn))
        using (var adapter = new MySqlDataAdapter(cmd))
        {
            adapter.Fill(tab);
        }
        return tab;
    }
    public static void Insert(string name, string email, string contact, string room, int guest, DateTime checkin, DateTime checkout, decimal pay)
    {
        string query = "INSERT INTO client (Name, Email_Address, Contact_Number, Number_of_Guests, Room_Type, Check_In, Check_out, Payment)" + "VALUES( @name, @email, @contact, @guest, @room, @checkin, @checkout, @pay)";
        using (var conn = getconn())
            using (var cmd = new MySqlCommand(query,conn))
        {
           
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@contact",contact);
            cmd.Parameters.AddWithValue("@room", room);
            cmd.Parameters.AddWithValue("@guest", guest);
            cmd.Parameters.AddWithValue("@checkin", checkin);
            cmd.Parameters.AddWithValue("@checkout", checkout);
            cmd.Parameters.AddWithValue("@pay", pay);
            conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
    public static void update(int id,string name, string email, string contact, string room, int guest, DateTime checkin, DateTime checkout, decimal pay)
    {
        string query = "UPDATE client SET Name=@name, Email_Address=@email, Contact_Number=@contact, Number_of_Guests=@guest, Room_Type=@room, Check_In=@checkin, Check_out=@checkout, Payment=@pay WHERE id=@id";
        using (var conn = getconn())
        using (var cmd = new MySqlCommand(query, conn))
        {
            cmd.Parameters.AddWithValue("@name", id);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@contact", contact);
            cmd.Parameters.AddWithValue("@room", room);
            cmd.Parameters.AddWithValue("@guest", guest);
            cmd.Parameters.AddWithValue("@checkin", checkin);
            cmd.Parameters.AddWithValue("@checkout", checkout);
            cmd.Parameters.AddWithValue("@pay", pay);
            conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
    public static void Delete(int id)
    {
        using (var conn = getconn())
        using (var cmd = new MySqlCommand("DELETE FROM client WHERE id=@id", conn))
        {
            cmd.Parameters.AddWithValue("id", id);
            conn.Open();    
            cmd .ExecuteNonQuery();
        }
    }

    internal static void update(string text1, string text2, string text3, string text4, int value1, DateTime value2, DateTime value3, decimal pay)
    {
        throw new NotImplementedException();
    }
}
