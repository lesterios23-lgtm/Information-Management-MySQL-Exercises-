﻿using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Hotel_Room_Reservation
{
    public partial class Book : Form
    {
        public event EventHandler Reservationupdated;
        public event EventHandler ReservationSaved;
        private int reservationid;
        public Book(string dbconn)
        {
            InitializeComponent();
           
         
        }

        public Book()
        {
            InitializeComponent();
        }
        private int GetReservationid()
        {
            return reservationid;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dtpout_ValueChanged(object sender, EventArgs e)
        {

        }

        private void tbpay_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbroom_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tbcontact_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtpin_ValueChanged(object sender, EventArgs e)
        {

        }

        private void tbname_TextChanged(object sender, EventArgs e)
        {

        }

        private void ndguest_ValueChanged(object sender, EventArgs e)
        {

        }

        private void NAME_Click(object sender, EventArgs e)
        {

        }

        private void btnsubmit_Click(object sender, EventArgs e, EventHandler update)
        {
            try
            {
                decimal pay = decimal.Parse(tbpay.Text);
                dbconnect.Insert(tbname.Text, tbemail.Text,(string) tbcontact.Text, cbroom.Text, (int)ndguest.Value, dtpin.Value, dtpout.Value, pay);

                MessageBox.Show("Reservation Successful!");
                ReservationSaved?.Invoke(this, EventArgs.Empty);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);

            }
            
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.FormClosed += (s, args) => this.Close();
            form1.Show();
        }

        private void Book_Load(object sender, EventArgs e)
        {
           
        }
    }
}
