﻿namespace Hotel_Room_Reservation
{
    partial class update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnback = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.updateout = new System.Windows.Forms.DateTimePicker();
            this.updatepay = new System.Windows.Forms.TextBox();
            this.updateroom = new System.Windows.Forms.ComboBox();
            this.updatecontact = new System.Windows.Forms.TextBox();
            this.updateemail = new System.Windows.Forms.TextBox();
            this.updatein = new System.Windows.Forms.DateTimePicker();
            this.updatename = new System.Windows.Forms.TextBox();
            this.updateguest = new System.Windows.Forms.NumericUpDown();
            this.NAME = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.updateguest)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnback.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnback.Location = new System.Drawing.Point(3, 3);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(121, 33);
            this.btnback.TabIndex = 37;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(223, 406);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 28);
            this.label7.TabIndex = 36;
            this.label7.Text = "Check out";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(77, 406);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 28);
            this.label6.TabIndex = 35;
            this.label6.Text = "Check In";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(223, 338);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 28);
            this.label5.TabIndex = 34;
            this.label5.Text = "Room Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(76, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 28);
            this.label4.TabIndex = 33;
            this.label4.Text = "No of Guest";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(76, 265);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 28);
            this.label3.TabIndex = 32;
            this.label3.Text = "Payment";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(77, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 28);
            this.label2.TabIndex = 31;
            this.label2.Text = "Contact No.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(77, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 28);
            this.label1.TabIndex = 30;
            this.label1.Text = "E-mail ";
            // 
            // updateout
            // 
            this.updateout.Location = new System.Drawing.Point(228, 437);
            this.updateout.Name = "updateout";
            this.updateout.Size = new System.Drawing.Size(120, 22);
            this.updateout.TabIndex = 29;
            // 
            // updatepay
            // 
            this.updatepay.Location = new System.Drawing.Point(75, 297);
            this.updatepay.Multiline = true;
            this.updatepay.Name = "updatepay";
            this.updatepay.Size = new System.Drawing.Size(273, 38);
            this.updatepay.TabIndex = 28;
            // 
            // updateroom
            // 
            this.updateroom.FormattingEnabled = true;
            this.updateroom.Items.AddRange(new object[] {
            "single Bed",
            "Douyble Bed",
            "Family size Bed "});
            this.updateroom.Location = new System.Drawing.Point(227, 369);
            this.updateroom.Name = "updateroom";
            this.updateroom.Size = new System.Drawing.Size(121, 24);
            this.updateroom.TabIndex = 27;
            // 
            // updatecontact
            // 
            this.updatecontact.Location = new System.Drawing.Point(75, 224);
            this.updatecontact.Multiline = true;
            this.updatecontact.Name = "updatecontact";
            this.updatecontact.Size = new System.Drawing.Size(273, 38);
            this.updatecontact.TabIndex = 26;
            // 
            // updateemail
            // 
            this.updateemail.Location = new System.Drawing.Point(75, 150);
            this.updateemail.Multiline = true;
            this.updateemail.Name = "updateemail";
            this.updateemail.Size = new System.Drawing.Size(273, 38);
            this.updateemail.TabIndex = 25;
            // 
            // updatein
            // 
            this.updatein.Location = new System.Drawing.Point(75, 437);
            this.updatein.Name = "updatein";
            this.updatein.Size = new System.Drawing.Size(120, 22);
            this.updatein.TabIndex = 24;
            this.updatein.Value = new System.DateTime(2025, 10, 31, 0, 0, 0, 0);
            // 
            // updatename
            // 
            this.updatename.Location = new System.Drawing.Point(75, 83);
            this.updatename.Multiline = true;
            this.updatename.Name = "updatename";
            this.updatename.Size = new System.Drawing.Size(273, 38);
            this.updatename.TabIndex = 23;
            // 
            // updateguest
            // 
            this.updateguest.Location = new System.Drawing.Point(75, 369);
            this.updateguest.Name = "updateguest";
            this.updateguest.Size = new System.Drawing.Size(120, 22);
            this.updateguest.TabIndex = 22;
            // 
            // NAME
            // 
            this.NAME.AutoSize = true;
            this.NAME.BackColor = System.Drawing.Color.Transparent;
            this.NAME.Font = new System.Drawing.Font("Microsoft Himalaya", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NAME.Location = new System.Drawing.Point(77, 59);
            this.NAME.Name = "NAME";
            this.NAME.Size = new System.Drawing.Size(61, 28);
            this.NAME.TabIndex = 21;
            this.NAME.Text = "Name";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.btnUpdate.Font = new System.Drawing.Font("Lucida Sans Typewriter", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnUpdate.Location = new System.Drawing.Point(97, 496);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(222, 41);
            this.btnUpdate.TabIndex = 20;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
           
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.btnback);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.updateout);
            this.panel1.Controls.Add(this.updatepay);
            this.panel1.Controls.Add(this.updateroom);
            this.panel1.Controls.Add(this.updatecontact);
            this.panel1.Controls.Add(this.updateemail);
            this.panel1.Controls.Add(this.updatein);
            this.panel1.Controls.Add(this.updatename);
            this.panel1.Controls.Add(this.updateguest);
            this.panel1.Controls.Add(this.NAME);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Location = new System.Drawing.Point(12, 11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(423, 596);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 618);
            this.Controls.Add(this.panel1);
            this.Name = "update";
            this.Text = "Update";
            this.Load += new System.EventHandler(this.Update_Load);
            ((System.ComponentModel.ISupportInitialize)(this.updateguest)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker updateout;
        private System.Windows.Forms.TextBox updatepay;
        private System.Windows.Forms.ComboBox updateroom;
        private System.Windows.Forms.TextBox updatecontact;
        private System.Windows.Forms.TextBox updateemail;
        private System.Windows.Forms.DateTimePicker updatein;
        private System.Windows.Forms.TextBox updatename;
        private System.Windows.Forms.NumericUpDown updateguest;
        private System.Windows.Forms.Label NAME;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Panel panel1;
    }
}